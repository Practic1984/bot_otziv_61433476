# TOKEN = "6192798371:AAGaLj8lllkkx8k39hi85kgGpVQnUZKHZno" # https://t.me/template_test2023_bot
TOKEN = "6872444918:AAGb05OponyHNDEJnAhmJkcQcEAYr5IyyGY" # https://t.me/GarmentGurusBot
ADMIN_LIST = [1029045407, 726716228]
GROUP_SPEC = -1002091147867 # https://t.me/+Zr9Gek8eSVhjMDFi